<?php

function Soma(float $v1, float $v2) {
    return ($v1 + $v2);
}

function Subtracao(float $v1, float $v2) {
    return ($v1 - $v2);
}

function Multiplicacao(float $v1, float $v2) {
    return ($v1 * $v2);
}

function Divisao(float $v1, float $v2) {
    return ($v1 / $v2);
}
