<?php

/*
  Crie um documento que exiba a seguinte mensagem “Olá, eu estou aprendendo PHP!”.
 */

echo "Olá, eu estou aprendendo PHP!";
//echo 'Olá, eu estou aprendendo PHP!';
