<?php

/*
 * Crie um array com os seguintes valores: Mouse, Teclado, Monitor, Gabinete, Estabilizador e Caixa de som. 
 * Exiba na tela através de seu respectivo índice, apenas o Teclado e o Gabinete.
 */

$arr = ["Mouse", "Teclado", "Monitor", "Gabinete", "Estabilizador", "Caixa de som"];

echo $arr[1] . "<br />";
echo $arr[3] . "<br />";
?>