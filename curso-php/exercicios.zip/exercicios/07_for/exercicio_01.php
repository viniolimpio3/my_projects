<?php

/*
 * Crie uma repetição utilizando o for que exiba na tela o valor do índice atual, 
 * como por exemplo:  Índice 1, índice 2... índice 9. 
 */

for ($i = 0; $i <= 20; $i++) {
    echo "Índice {$i}<br/>";
}