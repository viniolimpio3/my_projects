<?php

/*
  Declare uma variável chama indice e atribua a ela o valor 0, em seguida utilizando while,
 * incremente 1 a cada repetição e exiba o valor na tela. A condição de saída para o while 
 * deve ser quando o índice for menor que 20.
 */
$indice = 0;

while ($indice < 20) {
    echo "Valor: {$indice} <br />";
    $indice++;
}
?>