<?php

/*
 * Crie uma função que receba dois números por parâmetros e retorne a multiplicação entre eles, exiba o valor na tela.
 */

function Soma($v1, $v2) {
    return ($v1 * $v2);
}

echo Soma(10, 8);