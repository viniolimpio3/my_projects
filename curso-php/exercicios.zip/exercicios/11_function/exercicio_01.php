<?php

/* 
 * Crie uma função que mostre a soma de dois números.
 */

function Soma(){
    echo (3 + 6);
}

Soma();

