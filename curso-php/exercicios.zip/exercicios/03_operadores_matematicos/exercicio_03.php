<?php

/* 
 Crie uma variável responsável por receber a subtração de dois números
 quaisquer, na sequencia crie uma segunda variável que receba o valor 
 da variável anterior e divida por 100. 
 */

//Forma 1
$sub = 32 - 7;
$div = $sub / 100;
//echo $div;

//Forma 2
$result = (32 - 7) / 100;
//echo $result;

//Forma 3
echo  (32 - 7) / 100;
