<?php

/*
  Exiba na tela a soma de 87 + 45, com o resultado multiplique por 3, exiba o resultado na tela.
 */

//Forma 1
$v1 = 87 + 45;
$v2 = $v1 * 3;
//echo $v2;

//Forma 2
$v1 = (87 + 45) * 3;
//echo $v1;

//Forma 3
echo (87 + 45) * 3;
?>