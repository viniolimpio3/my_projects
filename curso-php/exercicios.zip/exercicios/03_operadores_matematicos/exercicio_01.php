<?php

/* 
Crie uma variável que receba o resultado de 1200 + 450.78, exiba o resultado na tela.
 */

$resultado = 1200 + 450.78;
echo "Soma: {$resultado}";
?>
