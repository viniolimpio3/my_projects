<?php

echo filter_input(INPUT_COOKIE, "nome", FILTER_SANITIZE_STRING);

