<?php

/*
  Declare uma variável que armazene o salario de 3.720.
 */

$salario = 3.700;
//echo $salario;
//echo number_format($salario, 2, ",", " ");
