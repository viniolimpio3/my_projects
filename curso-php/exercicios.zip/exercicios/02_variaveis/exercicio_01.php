<?php

/*
 Declare uma variável chamada nome e atribua o seu nome a ela.
 */

$nome = "Pedro Dias";
echo $nome;