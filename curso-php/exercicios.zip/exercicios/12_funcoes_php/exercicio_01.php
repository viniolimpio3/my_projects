<?php

/* 
 * Crie uma função que receba uma string e exiba a quantidade de caracteres contidas.
 */

//Exemplo 1
$str = "Feliz aquele que transfere o que sabe e aprende o que ensina. Cora Coralina.";
echo strlen($str);

//Exemplo 2
//echo strlen("Feliz aquele que transfere o que sabe e aprende o que ensina. Cora Coralina.");