<?php


$nomeCompleto = "Gunnar Correa";
//$idade = 29;
echo $nomeCompleto;
//echo $idade; 