<?php

$arryNotas = array(
    "aluno1" => array(
        "nome" => "Julia",
        "nota" => 10
    )
);

echo $arryNotas["aluno1"]["nota"];
