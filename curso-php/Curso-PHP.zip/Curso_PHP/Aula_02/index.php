<?php
$nome = "Gunnar";

echo "Meu nome é Cida <br />";
echo "Meu nome é: {$nome} <br />";
echo "Meu nome é: " . $nome . "<br />";
print "Meu nome é Cida";
